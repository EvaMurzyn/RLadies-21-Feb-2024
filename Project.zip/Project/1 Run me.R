#### This is an example project structure and running order####

# Call libraries
library(tidyverse)
library(readxl)
library(lubridate)

# Process data
source("Scripts/data_processing.R")


# Run and save an html report

rmarkdown::render("Scripts/report.Rmd", # run this markdown file
                  output_dir = "Output/", # where you want to save it
                  output_file = paste0("Performance for week ending ", 
                                       # save using this name
                                       format(max_date, "%d %B %Y"))) 
                                      # including the formatted date

