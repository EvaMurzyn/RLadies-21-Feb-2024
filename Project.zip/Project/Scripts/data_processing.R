### Data source:
# https://www.publichealthscotland.scot/our-areas-of-work/acute-and-emergency-services/urgent-and-unscheduled-care/accident-and-emergency/#section-4


# read in the data. The code below will find any file that matches the search string. 
# In this case, it will disregard the date at start of file name
# This means that you don't have to update the code every time you use a new weekly file


file_path <- list.files(path = "Input/", # specify the sub folder
                        pattern = "^(.*)-ed-weekly-attendance-and-waiting-times.xlsx$",  # search string
                        full.names = TRUE) # we want to include the full path to the file

# We can now use this to read in our data and do some preliminary transformations
# 1 - add week numbers and years to help with comparisons
# 2 - change dates from POSIXct to plain Date objects

scot_data <- read_excel(file_path, sheet = 3) %>%  # read in third sheet
  mutate(WeekEndingDate = as.Date(as.character(WeekEndingDate)), # change date to a plain date format
                     Year = isoyear(WeekEndingDate), # generate ISO year
                     Week = isoweek(WeekEndingDate)) # generate ISO week number
  
board_data <- read_excel(file_path, sheet = 4) %>%  # read in fourth sheet
  mutate(WeekEndingDate = as.Date(as.character(WeekEndingDate)),
         Year = isoyear(WeekEndingDate),
         Week = isoweek(WeekEndingDate))
  
site_data <- read_excel(file_path, sheet = 5) %>% # read in fifth sheet
  mutate(WeekEndingDate = as.Date(as.character(WeekEndingDate)),
         Year = isoyear(WeekEndingDate),
         Week = isoweek(WeekEndingDate))

# Get the latest date present in the file - we will need it to run and save the markdown file

max_date <- max(scot_data$WeekEndingDate)
